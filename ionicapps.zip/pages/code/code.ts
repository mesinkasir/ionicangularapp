import { Component } from "@angular/core";
import { NavController } from "ionic-angular";

@Component({
  selector: "page-code",
  templateUrl: "code.html"
})
export class CodePage {
  constructor(public navCtrl: NavController) {}
}
